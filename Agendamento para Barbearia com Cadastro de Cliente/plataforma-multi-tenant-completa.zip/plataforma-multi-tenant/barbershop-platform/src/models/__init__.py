from flask_sqlalchemy import SQLAlchemy

# Instância principal do SQLAlchemy
db = SQLAlchemy()

# Importar todos os modelos para garantir que sejam registrados
from .tenant import Tenant, TenantConfig, SubscriptionPlan
from .platform_user import PlatformUser
from .user import User  # Modelo original do template
from .service import Service
from .staff import Staff
from .client import Client
from .appointment import Appointment

# Função para inicializar o banco de dados
def init_db(app):
    """Inicializa o banco de dados com a aplicação Flask"""
    # Não inicializar novamente se já foi inicializado
    if not hasattr(app, 'extensions') or 'sqlalchemy' not in app.extensions:
        db.init_app(app)
    
    with app.app_context():
        # Criar todas as tabelas
        db.create_all()
        
        # Criar dados iniciais se necessário
        create_initial_data()

def create_initial_data():
    """Cria dados iniciais necessários para o funcionamento da plataforma"""
    
    # Criar planos de assinatura padrão
    if not SubscriptionPlan.query.first():
        plans = [
            SubscriptionPlan(
                name='Básico',
                description='Plano ideal para barbearias pequenas',
                price=49.00,
                billing_cycle='monthly',
                max_appointments=100,
                max_staff=1,
                features={
                    'agendamentos': 100,
                    'funcionarios': 1,
                    'personalizacao_basica': True,
                    'suporte_email': True,
                    'relatorios_basicos': True,
                    'app_cliente': True
                }
            ),
            SubscriptionPlan(
                name='Profissional',
                description='Plano completo para barbearias em crescimento',
                price=99.00,
                billing_cycle='monthly',
                max_appointments=None,  # Ilimitado
                max_staff=5,
                features={
                    'agendamentos': 'ilimitado',
                    'funcionarios': 5,
                    'personalizacao_completa': True,
                    'suporte_prioritario': True,
                    'relatorios_avancados': True,
                    'integracao_whatsapp': True,
                    'sistema_avaliacoes': True,
                    'marketing_email': True
                }
            ),
            SubscriptionPlan(
                name='Premium',
                description='Plano premium com todos os recursos',
                price=199.00,
                billing_cycle='monthly',
                max_appointments=None,  # Ilimitado
                max_staff=None,  # Ilimitado
                features={
                    'agendamentos': 'ilimitado',
                    'funcionarios': 'ilimitado',
                    'api_personalizada': True,
                    'suporte_telefonico': True,
                    'analytics_avancados': True,
                    'integracao_redes_sociais': True,
                    'sistema_fidelidade': True,
                    'multiplas_unidades': True
                }
            )
        ]
        
        for plan in plans:
            db.session.add(plan)
        
        db.session.commit()
        print("Planos de assinatura criados com sucesso!")
    
    # Criar super admin padrão se não existir
    if not PlatformUser.query.filter_by(role='super_admin').first():
        super_admin = PlatformUser.create_super_admin(
            email='admin@barbershop-platform.com',
            password='admin123',  # Mudar em produção
            first_name='Super',
            last_name='Admin'
        )
        
        db.session.add(super_admin)
        db.session.commit()
        print("Super admin criado com sucesso!")
        print("Email: admin@barbershop-platform.com")
        print("Senha: admin123")
        print("IMPORTANTE: Altere a senha em produção!")

# Exportar instância do db e modelos principais
__all__ = [
    'db',
    'Tenant',
    'TenantConfig', 
    'SubscriptionPlan',
    'PlatformUser',
    'User',
    'Service',
    'Staff',
    'Client',
    'Appointment',
    'init_db',
    'create_initial_data'
]

