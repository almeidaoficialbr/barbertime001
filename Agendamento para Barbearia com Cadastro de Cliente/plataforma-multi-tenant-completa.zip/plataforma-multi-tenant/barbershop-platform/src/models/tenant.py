from datetime import datetime
from sqlalchemy import Column, Integer, String, DateTime, Boolean, Text, JSON
from sqlalchemy.orm import relationship
from src.models import db
from datetime import datetime

class Tenant(db.Model):
    """Modelo para representar uma barbearia (tenant)"""
    __tablename__ = 'tenants'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(255), nullable=False)
    slug = Column(String(100), unique=True, nullable=False)
    domain = Column(String(255), unique=True, nullable=True)
    status = Column(String(20), default='active')
    plan_id = Column(Integer, nullable=True)
    subscription_expires_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    deleted_at = Column(DateTime, nullable=True)
    
    # Relacionamentos
    services = relationship('Service', back_populates='tenant', lazy='dynamic')
    staff = relationship('Staff', back_populates='tenant', lazy='dynamic')
    clients = relationship('Client', back_populates='tenant', lazy='dynamic')
    appointments = relationship('Appointment', back_populates='tenant', lazy='dynamic')
    
    def __repr__(self):
        return f'<Tenant {self.name}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'slug': self.slug,
            'domain': self.domain,
            'status': self.status,
            'plan_id': self.plan_id,
            'subscription_expires_at': self.subscription_expires_at.isoformat() if self.subscription_expires_at else None,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat()
        }

class TenantConfig(db.Model):
    """Configurações personalizadas de cada tenant"""
    __tablename__ = 'tenant_configs'
    
    id = Column(Integer, primary_key=True)
    tenant_id = Column(Integer, db.ForeignKey('tenants.id'), nullable=False)
    logo_url = Column(String(500), nullable=True)
    primary_color = Column(String(7), default='#1A1A1A')
    secondary_color = Column(String(7), default='#B8860B')
    accent_color = Column(String(7), default='#8B0000')
    business_name = Column(String(255), nullable=True)
    description = Column(Text, nullable=True)
    address = Column(Text, nullable=True)
    city = Column(String(100), default='Brejo')
    state = Column(String(2), default='MA')
    zip_code = Column(String(10), nullable=True)
    phone = Column(String(20), nullable=True)
    email = Column(String(255), nullable=True)
    website = Column(String(255), nullable=True)
    instagram = Column(String(100), nullable=True)
    facebook = Column(String(100), nullable=True)
    whatsapp = Column(String(20), nullable=True)
    opening_hours = Column(JSON, nullable=True)
    policies = Column(JSON, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relacionamento
    tenant = db.relationship('Tenant', backref=db.backref('config', uselist=False))
    
    def __repr__(self):
        return f'<TenantConfig for {self.tenant.name if self.tenant else "Unknown"}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'tenant_id': self.tenant_id,
            'logo_url': self.logo_url,
            'primary_color': self.primary_color,
            'secondary_color': self.secondary_color,
            'accent_color': self.accent_color,
            'business_name': self.business_name,
            'description': self.description,
            'address': self.address,
            'city': self.city,
            'state': self.state,
            'zip_code': self.zip_code,
            'phone': self.phone,
            'email': self.email,
            'website': self.website,
            'instagram': self.instagram,
            'facebook': self.facebook,
            'whatsapp': self.whatsapp,
            'opening_hours': self.opening_hours,
            'policies': self.policies,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat()
        }

class SubscriptionPlan(db.Model):
    """Planos de assinatura disponíveis"""
    __tablename__ = 'subscription_plans'
    
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    description = Column(Text, nullable=True)
    price = Column(db.Numeric(10, 2), nullable=False)
    billing_cycle = Column(String(20), default='monthly')  # monthly, yearly
    max_appointments = Column(Integer, nullable=True)
    max_staff = Column(Integer, nullable=True)
    features = Column(JSON, nullable=True)
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    def __repr__(self):
        return f'<SubscriptionPlan {self.name}>'
    
    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'price': float(self.price),
            'billing_cycle': self.billing_cycle,
            'max_appointments': self.max_appointments,
            'max_staff': self.max_staff,
            'features': self.features,
            'active': self.active,
            'created_at': self.created_at.isoformat()
        }

