import re
from flask import request, g, abort, current_app
from src.models import Tenant

class TenantMiddleware:
    """Middleware para resolução automática de tenant baseado no subdomínio ou header"""
    
    def __init__(self, app=None):
        self.app = app
        if app is not None:
            self.init_app(app)
    
    def init_app(self, app):
        """Inicializa o middleware com a aplicação Flask"""
        app.before_request(self.before_request)
        app.teardown_appcontext(self.teardown_appcontext)
    
    def before_request(self):
        """Executado antes de cada requisição para resolver o tenant"""
        
        # Pular resolução de tenant para rotas administrativas e públicas
        if self.should_skip_tenant_resolution():
            return
        
        # Tentar resolver tenant por diferentes métodos
        tenant = self.resolve_tenant()
        
        if tenant:
            # Armazenar tenant no contexto da requisição
            g.current_tenant = tenant
            g.tenant_id = tenant.id
            g.tenant_slug = tenant.slug
            
            # Verificar se o tenant está ativo
            if tenant.status != 'active':
                abort(503, description="Barbearia temporariamente indisponível")
        else:
            # Para rotas que requerem tenant, retornar erro
            if self.requires_tenant():
                abort(404, description="Barbearia não encontrada")
    
    def teardown_appcontext(self, exception):
        """Limpeza após a requisição"""
        # Limpar dados do tenant do contexto
        g.pop('current_tenant', None)
        g.pop('tenant_id', None)
        g.pop('tenant_slug', None)
    
    def should_skip_tenant_resolution(self):
        """Determina se deve pular a resolução de tenant para esta rota"""
        
        # Rotas que não precisam de tenant
        skip_patterns = [
            r'^/api/admin/',           # Rotas administrativas
            r'^/api/public/',          # Rotas públicas
            r'^/api/auth/login',       # Login
            r'^/api/auth/register',    # Registro
            r'^/static/',              # Arquivos estáticos
            r'^/favicon.ico',          # Favicon
            r'^/$',                    # Página inicial
        ]
        
        path = request.path
        for pattern in skip_patterns:
            if re.match(pattern, path):
                return True
        
        return False
    
    def requires_tenant(self):
        """Determina se a rota atual requer um tenant"""
        
        # Rotas que requerem tenant
        tenant_patterns = [
            r'^/api/tenant/',          # APIs específicas do tenant
            r'^/api/appointments/',    # Agendamentos
            r'^/api/clients/',         # Clientes
            r'^/api/services/',        # Serviços
            r'^/api/staff/',           # Funcionários
        ]
        
        path = request.path
        for pattern in tenant_patterns:
            if re.match(pattern, path):
                return True
        
        return False
    
    def resolve_tenant(self):
        """Resolve o tenant baseado em diferentes estratégias"""
        
        tenant = None
        
        # Estratégia 1: Header X-Tenant-Slug (para APIs)
        tenant_slug = request.headers.get('X-Tenant-Slug')
        if tenant_slug:
            tenant = Tenant.query.filter_by(slug=tenant_slug).first()
            if tenant:
                return tenant
        
        # Estratégia 2: Subdomínio
        if current_app.config.get('TENANT_SUBDOMAIN_ENABLED', True):
            tenant = self.resolve_by_subdomain()
            if tenant:
                return tenant
        
        # Estratégia 3: Parâmetro na URL
        tenant_slug = request.args.get('tenant')
        if tenant_slug:
            tenant = Tenant.query.filter_by(slug=tenant_slug).first()
            if tenant:
                return tenant
        
        # Estratégia 4: Domínio personalizado
        tenant = self.resolve_by_domain()
        if tenant:
            return tenant
        
        return None
    
    def resolve_by_subdomain(self):
        """Resolve tenant pelo subdomínio"""
        
        host = request.host.lower()
        
        # Extrair subdomínio
        # Exemplo: barbearia1.localhost:5000 -> barbearia1
        parts = host.split('.')
        
        if len(parts) >= 2:
            subdomain = parts[0]
            
            # Ignorar subdomínios reservados
            reserved_subdomains = ['www', 'api', 'admin', 'app', 'mail']
            if subdomain not in reserved_subdomains:
                tenant = Tenant.query.filter_by(slug=subdomain).first()
                return tenant
        
        return None
    
    def resolve_by_domain(self):
        """Resolve tenant pelo domínio personalizado"""
        
        host = request.host.lower()
        
        # Remover porta se presente
        if ':' in host:
            host = host.split(':')[0]
        
        tenant = Tenant.query.filter_by(domain=host).first()
        return tenant

def get_current_tenant():
    """Função helper para obter o tenant atual"""
    return getattr(g, 'current_tenant', None)

def get_tenant_id():
    """Função helper para obter o ID do tenant atual"""
    return getattr(g, 'tenant_id', None)

def get_tenant_slug():
    """Função helper para obter o slug do tenant atual"""
    return getattr(g, 'tenant_slug', None)

def require_tenant(f):
    """Decorator para rotas que requerem um tenant"""
    from functools import wraps
    
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not get_current_tenant():
            abort(404, description="Barbearia não encontrada")
        return f(*args, **kwargs)
    
    return decorated_function

