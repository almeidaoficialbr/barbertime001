from flask import Blueprint, request, jsonify
from flask_jwt_extended import jwt_required, get_jwt_identity
from sqlalchemy.exc import IntegrityError
from src.models import db, Staff, PlatformUser
from src.middleware.tenant import get_current_tenant
import json

staff_bp = Blueprint('staff', __name__)

@staff_bp.route('/', methods=['GET'])
@jwt_required()
def list_staff():
    """Listar todos os funcionários do tenant"""
    try:
        tenant = get_current_tenant()
        if not tenant:
            return jsonify({'error': 'Tenant não encontrado'}), 404
        
        # Parâmetros de filtro
        is_active = request.args.get('is_active', 'true').lower() == 'true'
        position = request.args.get('position')
        
        # Query base
        query = Staff.query.filter_by(tenant_id=tenant.id)
        
        # Aplicar filtros
        if is_active is not None:
            query = query.filter_by(is_active=is_active)
        
        if position:
            query = query.filter_by(position=position)
        
        # Ordenar por nome
        staff_members = query.order_by(Staff.name).all()
        
        return jsonify({
            'staff': [member.to_dict() for member in staff_members],
            'total': len(staff_members)
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@staff_bp.route('/', methods=['POST'])
@jwt_required()
def create_staff():
    """Criar novo funcionário"""
    try:
        tenant = get_current_tenant()
        if not tenant:
            return jsonify({'error': 'Tenant não encontrado'}), 404
        
        data = request.get_json()
        
        # Validar dados obrigatórios
        required_fields = ['name', 'position']
        for field in required_fields:
            if field not in data:
                return jsonify({'error': f'Campo {field} é obrigatório'}), 400
        
        # Verificar se email já existe (se fornecido)
        if data.get('email'):
            existing_staff = Staff.query.filter_by(
                tenant_id=tenant.id,
                email=data['email']
            ).first()
            if existing_staff:
                return jsonify({'error': 'Email já cadastrado para outro funcionário'}), 400
        
        # Processar especialidades (JSON)
        specialties = data.get('specialties', [])
        if isinstance(specialties, list):
            specialties = json.dumps(specialties)
        
        # Processar horário de trabalho (JSON)
        work_schedule = data.get('work_schedule', {})
        if isinstance(work_schedule, dict):
            work_schedule = json.dumps(work_schedule)
        
        # Criar novo funcionário
        staff_member = Staff(
            tenant_id=tenant.id,
            name=data['name'],
            email=data.get('email'),
            phone=data.get('phone'),
            photo_url=data.get('photo_url'),
            bio=data.get('bio'),
            position=data['position'],
            specialties=specialties,
            experience_years=data.get('experience_years'),
            work_schedule=work_schedule,
            is_active=data.get('is_active', True)
        )
        
        db.session.add(staff_member)
        db.session.commit()
        
        return jsonify({
            'message': 'Funcionário criado com sucesso',
            'staff': staff_member.to_dict()
        }), 201
        
    except ValueError as e:
        return jsonify({'error': 'Dados inválidos: ' + str(e)}), 400
    except IntegrityError:
        db.session.rollback()
        return jsonify({'error': 'Erro de integridade dos dados'}), 400
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@staff_bp.route('/<int:staff_id>', methods=['GET'])
@jwt_required()
def get_staff(staff_id):
    """Obter detalhes de um funcionário específico"""
    try:
        tenant = get_current_tenant()
        if not tenant:
            return jsonify({'error': 'Tenant não encontrado'}), 404
        
        staff_member = Staff.query.filter_by(
            id=staff_id,
            tenant_id=tenant.id
        ).first()
        
        if not staff_member:
            return jsonify({'error': 'Funcionário não encontrado'}), 404
        
        return jsonify({'staff': staff_member.to_dict()}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@staff_bp.route('/<int:staff_id>', methods=['PUT'])
@jwt_required()
def update_staff(staff_id):
    """Atualizar funcionário existente"""
    try:
        tenant = get_current_tenant()
        if not tenant:
            return jsonify({'error': 'Tenant não encontrado'}), 404
        
        staff_member = Staff.query.filter_by(
            id=staff_id,
            tenant_id=tenant.id
        ).first()
        
        if not staff_member:
            return jsonify({'error': 'Funcionário não encontrado'}), 404
        
        data = request.get_json()
        
        # Verificar se email já existe (se sendo alterado)
        if 'email' in data and data['email'] != staff_member.email:
            existing_staff = Staff.query.filter_by(
                tenant_id=tenant.id,
                email=data['email']
            ).first()
            if existing_staff:
                return jsonify({'error': 'Email já cadastrado para outro funcionário'}), 400
        
        # Atualizar campos permitidos
        if 'name' in data:
            staff_member.name = data['name']
        if 'email' in data:
            staff_member.email = data['email']
        if 'phone' in data:
            staff_member.phone = data['phone']
        if 'photo_url' in data:
            staff_member.photo_url = data['photo_url']
        if 'bio' in data:
            staff_member.bio = data['bio']
        if 'position' in data:
            staff_member.position = data['position']
        if 'specialties' in data:
            specialties = data['specialties']
            if isinstance(specialties, list):
                specialties = json.dumps(specialties)
            staff_member.specialties = specialties
        if 'experience_years' in data:
            staff_member.experience_years = data['experience_years']
        if 'work_schedule' in data:
            work_schedule = data['work_schedule']
            if isinstance(work_schedule, dict):
                work_schedule = json.dumps(work_schedule)
            staff_member.work_schedule = work_schedule
        if 'is_active' in data:
            staff_member.is_active = data['is_active']
        
        db.session.commit()
        
        return jsonify({
            'message': 'Funcionário atualizado com sucesso',
            'staff': staff_member.to_dict()
        }), 200
        
    except ValueError as e:
        return jsonify({'error': 'Dados inválidos: ' + str(e)}), 400
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@staff_bp.route('/<int:staff_id>', methods=['DELETE'])
@jwt_required()
def delete_staff(staff_id):
    """Excluir funcionário"""
    try:
        tenant = get_current_tenant()
        if not tenant:
            return jsonify({'error': 'Tenant não encontrado'}), 404
        
        staff_member = Staff.query.filter_by(
            id=staff_id,
            tenant_id=tenant.id
        ).first()
        
        if not staff_member:
            return jsonify({'error': 'Funcionário não encontrado'}), 404
        
        # Verificar se há agendamentos futuros associados
        from datetime import datetime
        future_appointments = [apt for apt in staff_member.appointments 
                             if apt.appointment_date > datetime.utcnow()]
        
        if future_appointments:
            return jsonify({
                'error': 'Não é possível excluir funcionário com agendamentos futuros'
            }), 400
        
        db.session.delete(staff_member)
        db.session.commit()
        
        return jsonify({'message': 'Funcionário excluído com sucesso'}), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@staff_bp.route('/<int:staff_id>/schedule', methods=['GET'])
@jwt_required()
def get_staff_schedule(staff_id):
    """Obter horário de trabalho de um funcionário"""
    try:
        tenant = get_current_tenant()
        if not tenant:
            return jsonify({'error': 'Tenant não encontrado'}), 404
        
        staff_member = Staff.query.filter_by(
            id=staff_id,
            tenant_id=tenant.id
        ).first()
        
        if not staff_member:
            return jsonify({'error': 'Funcionário não encontrado'}), 404
        
        # Parsear horário de trabalho
        work_schedule = {}
        if staff_member.work_schedule:
            try:
                work_schedule = json.loads(staff_member.work_schedule)
            except json.JSONDecodeError:
                work_schedule = {}
        
        return jsonify({
            'staff_id': staff_id,
            'name': staff_member.name,
            'work_schedule': work_schedule
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@staff_bp.route('/<int:staff_id>/schedule', methods=['PUT'])
@jwt_required()
def update_staff_schedule(staff_id):
    """Atualizar horário de trabalho de um funcionário"""
    try:
        tenant = get_current_tenant()
        if not tenant:
            return jsonify({'error': 'Tenant não encontrado'}), 404
        
        staff_member = Staff.query.filter_by(
            id=staff_id,
            tenant_id=tenant.id
        ).first()
        
        if not staff_member:
            return jsonify({'error': 'Funcionário não encontrado'}), 404
        
        data = request.get_json()
        work_schedule = data.get('work_schedule', {})
        
        # Validar formato do horário
        valid_days = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday']
        for day, schedule in work_schedule.items():
            if day not in valid_days:
                return jsonify({'error': f'Dia inválido: {day}'}), 400
            
            if schedule and ('start' not in schedule or 'end' not in schedule):
                return jsonify({'error': f'Horário inválido para {day}'}), 400
        
        # Atualizar horário
        staff_member.work_schedule = json.dumps(work_schedule)
        db.session.commit()
        
        return jsonify({
            'message': 'Horário atualizado com sucesso',
            'work_schedule': work_schedule
        }), 200
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@staff_bp.route('/positions', methods=['GET'])
@jwt_required()
def get_positions():
    """Listar posições/cargos disponíveis"""
    try:
        positions = [
            'barbeiro',
            'cabeleireiro',
            'recepcionista',
            'gerente',
            'proprietario',
            'estagiario',
            'assistente'
        ]
        
        return jsonify({'positions': positions}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

