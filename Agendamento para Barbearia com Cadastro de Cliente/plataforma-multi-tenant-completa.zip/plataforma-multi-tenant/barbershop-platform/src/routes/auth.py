from flask import Blueprint, request, jsonify
from flask_jwt_extended import create_access_token, create_refresh_token, jwt_required, get_jwt_identity
from datetime import datetime

from src.models import db, PlatformUser, Tenant

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['POST'])
def login():
    """Login de usuários da plataforma"""
    try:
        data = request.get_json()
        
        if not data or not data.get('email') or not data.get('password'):
            return jsonify({'error': 'Email e senha são obrigatórios'}), 400
        
        email = data['email'].lower().strip()
        password = data['password']
        
        # Buscar usuário
        user = PlatformUser.query.filter_by(email=email).first()
        
        if not user or not user.check_password(password):
            return jsonify({'error': 'Credenciais inválidas'}), 401
        
        if user.status != 'active':
            return jsonify({'error': 'Conta desativada'}), 401
        
        # Atualizar último login
        user.last_login_at = datetime.utcnow()
        db.session.commit()
        
        # Criar tokens JWT
        user_identity = str(user.id)  # Usar apenas o ID como string
        additional_claims = {
            'user_id': user.id,
            'email': user.email,
            'role': user.role,
            'tenant_id': user.tenant_id
        }
        
        access_token = create_access_token(
            identity=user_identity,
            additional_claims=additional_claims
        )
        refresh_token = create_refresh_token(
            identity=user_identity,
            additional_claims=additional_claims
        )
        
        # Dados do usuário para resposta
        user_data = user.to_dict()
        
        # Adicionar dados do tenant se aplicável
        if user.tenant:
            user_data['tenant'] = user.tenant.to_dict()
        
        return jsonify({
            'message': 'Login realizado com sucesso',
            'access_token': access_token,
            'refresh_token': refresh_token,
            'user': user_data
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor'}), 500

@auth_bp.route('/refresh', methods=['POST'])
@jwt_required(refresh=True)
def refresh():
    """Renovar token de acesso"""
    try:
        current_user_data = get_jwt_identity()
        
        # Verificar se usuário ainda existe e está ativo
        user = PlatformUser.query.get(current_user_data['user_id'])
        if not user or user.status != 'active':
            return jsonify({'error': 'Usuário inválido'}), 401
        
        # Criar novo token de acesso
        access_token = create_access_token(
            identity={
                'user_id': user.id,
                'email': user.email,
                'role': user.role,
                'tenant_id': user.tenant_id
            }
        )
        
        return jsonify({
            'access_token': access_token
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor'}), 500

@auth_bp.route('/me', methods=['GET'])
@jwt_required()
def get_current_user():
    """Obter dados do usuário atual"""
    try:
        current_user_data = get_jwt_identity()
        
        user = PlatformUser.query.get(current_user_data['user_id'])
        if not user:
            return jsonify({'error': 'Usuário não encontrado'}), 404
        
        user_data = user.to_dict()
        
        # Adicionar dados do tenant se aplicável
        if user.tenant:
            user_data['tenant'] = user.tenant.to_dict()
            if user.tenant.config:
                user_data['tenant']['config'] = user.tenant.config.to_dict()
        
        return jsonify({'user': user_data}), 200
        
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor'}), 500

@auth_bp.route('/register-tenant', methods=['POST'])
def register_tenant():
    """Registrar nova barbearia (tenant) e seu administrador"""
    try:
        data = request.get_json()
        
        # Validar dados obrigatórios
        required_fields = ['business_name', 'slug', 'admin_email', 'admin_password', 'admin_first_name']
        for field in required_fields:
            if not data.get(field):
                return jsonify({'error': f'Campo {field} é obrigatório'}), 400
        
        # Verificar se slug já existe
        if Tenant.query.filter_by(slug=data['slug']).first():
            return jsonify({'error': 'Este identificador já está em uso'}), 400
        
        # Verificar se email já existe
        if PlatformUser.query.filter_by(email=data['admin_email']).first():
            return jsonify({'error': 'Este email já está cadastrado'}), 400
        
        # Criar tenant
        tenant = Tenant(
            name=data['business_name'],
            slug=data['slug'],
            status='active',
            plan_id=1  # Plano básico por padrão
        )
        
        db.session.add(tenant)
        db.session.flush()  # Para obter o ID do tenant
        
        # Criar administrador do tenant
        admin = PlatformUser.create_tenant_admin(
            tenant_id=tenant.id,
            email=data['admin_email'],
            password=data['admin_password'],
            first_name=data['admin_first_name'],
            last_name=data.get('admin_last_name')
        )
        
        db.session.add(admin)
        
        # Criar configuração inicial do tenant
        from src.models.tenant import TenantConfig
        config = TenantConfig(
            tenant_id=tenant.id,
            business_name=data['business_name'],
            city='Brejo',
            state='MA',
            phone=data.get('phone'),
            email=data.get('business_email', data['admin_email'])
        )
        
        db.session.add(config)
        db.session.commit()
        
        return jsonify({
            'message': 'Barbearia registrada com sucesso',
            'tenant': tenant.to_dict(),
            'admin': admin.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': 'Erro interno do servidor'}), 500

@auth_bp.route('/forgot-password', methods=['POST'])
def forgot_password():
    """Solicitar recuperação de senha"""
    try:
        data = request.get_json()
        
        if not data or not data.get('email'):
            return jsonify({'error': 'Email é obrigatório'}), 400
        
        email = data['email'].lower().strip()
        user = PlatformUser.query.filter_by(email=email).first()
        
        # Sempre retornar sucesso por segurança (não revelar se email existe)
        return jsonify({
            'message': 'Se o email estiver cadastrado, você receberá instruções para recuperação'
        }), 200
        
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor'}), 500

@auth_bp.route('/logout', methods=['POST'])
@jwt_required()
def logout():
    """Logout do usuário"""
    try:
        # Em uma implementação completa, adicionaríamos o token a uma blacklist
        return jsonify({'message': 'Logout realizado com sucesso'}), 200
        
    except Exception as e:
        return jsonify({'error': 'Erro interno do servidor'}), 500

